package dkit.oop;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PassengerAirplane extends Airplane {
//    public static Scanner input = App.scanner;
//    // fields(Q2)
//    int MAX_NUM_PASSENGERS;
//    String passenger;
//    public static ArrayList passengers;
//
//

//    PassengerAirplane(String type, int maxNumPassengers) {
//        super(type);
//
//
//    }
//
//    public void addPassenger(String name) {
//        System.out.println("Enter name: ");
//        name = input.nextLine();
//
//    }
//    @Override
//    public String toString() {
//        return "Name: "+
//    }

} // end of PassengerAirplane
